This directory contains files created while collecting training data
